module Debase
  VERSION = "0.2.2" unless defined? VERSION
end
